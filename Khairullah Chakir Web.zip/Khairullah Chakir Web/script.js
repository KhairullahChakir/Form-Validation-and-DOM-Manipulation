// IWS — Validation + DOM write
document.getElementById('studentForm').addEventListener('submit', function(event) {
  event.preventDefault();

  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const age = document.getElementById('age').value;
  const message = document.getElementById('message').value.trim();

  // Basic checks just like the brief (alerts + early returns)
  if (name.length < 3) {
    alert('Name must be at least 3 characters long.');
    return;
  }

  // Simple email check to mirror the brief while being a bit stricter
  const emailOK = email.includes('@') && email.split('@')[1]?.includes('.');
  if (!emailOK) {
    alert('Please enter a valid email address.');
    return;
  }

  if (message.length < 10) {
    alert('Message must be at least 10 characters long.');
    return;
  }

  // Build safe HTML for the output
  const esc = (s) => s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const nameSafe = esc(name);
  const emailSafe = esc(email);
  const ageSafe = esc(String(age));
  const msgSafe = esc(message);

  document.getElementById('output').innerHTML =
    `<p><strong class="ok">${nameSafe}</strong> (<span class="muted">${emailSafe}</span>) - ${ageSafe || 'N/A'} years old</p>
     <p>Message: ${msgSafe}</p>`;

  // Reset the form
  document.getElementById('studentForm').reset();
});
