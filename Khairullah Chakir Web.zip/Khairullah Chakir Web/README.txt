IWS Deliverables (generated 2025-10-19T21:40:41)
--------------------------------------------------
Files:
- index.html  -> main page with the form and output area
- script.js   -> JavaScript validation and DOM update logic

How to run:
1) Download both files into the same folder.
2) Open index.html in your browser.
3) Test invalid inputs (short name, wrong email, short message) to see alerts.
4) Submit valid input and watch the output section update without a page refresh.
5) Take screenshots showing:
   - An alert for invalid name
   - An alert for invalid email
   - An alert for short message
   - The output card showing rendered submission

Notes:
- Logic follows the given brief: alerts + innerHTML assignment + form reset.
- Extra: basic escaping is added before writing to innerHTML to avoid HTML injection.
